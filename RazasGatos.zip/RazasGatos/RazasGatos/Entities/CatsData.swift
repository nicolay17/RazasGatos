//
//  CatsData.swift
//  RazasGatos
//
//  Created by Nicolay Martinez on 10/03/23.
//

import Foundation

struct Cats: Decodable{
    
    let breedName:      String
    let origin:         String
    let affectionLevel: Int
    let intelligence:   Int
    let imageUrl:       String
}

//
//  CatsViewCell.swift
//  RazasGatos
//
//  Created by Nicolay Martinez on 10/03/23.
//

import UIKit

class CatsViewCell: UITableViewCell {
    
    @IBOutlet weak var name: UILabel!
    
    @IBOutlet weak var imagen: UIImageView!
    
    @IBOutlet weak var origin: UILabel!
    
    @IBOutlet weak var intelligence: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}

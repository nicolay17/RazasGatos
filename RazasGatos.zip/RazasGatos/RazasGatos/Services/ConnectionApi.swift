//
//  ConnectionApi.swift
//  RazasGatos
//
//  Created by Nicolay Martinez on 10/03/23.
//

import Foundation

protocol catsManagerDelegate{
    func listCats(list:[Cats])
}

struct CatsManager{
    var delegate: catsManagerDelegate?
    
    func toListCats(){
        let session = URLSession.shared
        let urlString = "https://api.thecatapi.com/v1/breeds"
        let keyApi = "x-api-key:bda53789e-46cd-9bc4-9bc4-2936630fde39"
        
        guard let url = URL(string: urlString)else{return}
        var request = URLRequest(url: url)
        request.httpMethod = "GET"
        request.addValue(keyApi, forHTTPHeaderField: "API-KEY")
        let task = session.dataTask(with: request){data,result,error in
            if error != nil{
                print("error")
            }
            if let dataResult = data{
                if let listCats = self.parsearJSON(dataResult:dataResult){
                    print(listCats)
                    delegate?.listCats(list: listCats)
                }
            }
            
        }
        
    }
    func parsearJSON(dataResult: Data)-> [Cats]?{
        let decoded = JSONDecoder()
        do{
            let dataCatsDecoded = try decoded.decode([Cats].self, from: dataResult)
            return dataCatsDecoded
        }catch{
            return nil
        }
    }
}



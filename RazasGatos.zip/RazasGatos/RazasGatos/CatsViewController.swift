//
//  ViewController.swift
//  RazasGatos
//
//  Created by Nicolay Martinez on 10/03/23.
//

import UIKit

class CatsViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    @IBOutlet weak var tableCats: UITableView!
    var catsManager = CatsManager()
    
    var cats:[Cats]=[]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableCats.delegate = self
        tableCats.dataSource = self
        catsManager.toListCats()
        
        // Do any additional setup after loading the view.
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return cats.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableCats.dequeueReusableCell(withIdentifier: "cell",for: indexPath) as! CatsViewCell
        
        cell.name.text = cats[indexPath.row].breedName
        cell.intelligence.text = cats[indexPath.row].intelligence
        cell.origin.text = cats[indexPath.row].origin
         
        if let urlString = cats[indexPath.row].imageUrl as? String{
            if let imagenURL = URL(string: urlString){
                DispatchQueue.global().async {
                    guard let imagenData = try? Data(contentsOf: imagenURL)else{
                        return
                        let imagen = UIImage(data:imagenData)
                        DispatchQueue.main.async {
                            cell.imagen.image= imegen
                        }
                    }
                }
            }
        }
        return cell
    }
}

extension CatsViewController: catsManagerDelegate{
    func listCats(list: [Cats]) {
        cats = list
        
        DispatchQueue.main.async {
            self.tableCats.reloadData()
        }
    }
}

